# Machine Learning HW5
## b03902089 資工三 林良翰

* Environment: MAC OS X Yosemite 10.10.5
* Run the program: 
  `python3 2~4.py`
  `python3 11~16.py [problem_no]`
* Comments:
	* Problem 11 ~ 16 will generate graph with filename `[problem_no].png`
	* `python3 11~16.py 12` and `python3 11~16.py 13` will execute the same code, and generate two graph `12.png`, `13.png`.
