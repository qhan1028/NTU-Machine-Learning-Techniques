# ML2017 hw5 porblem 9.

import numpy as np
from numpy.linalg import *


